<div class="modal fade" data-backdrop="static" id="paymentMethodModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog ">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Pay Now</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table">
                    <tbody id="paymentList">

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\shahbaj\Downloads\laravel ecom app\Ecommerce\apple-shop\apple-shop\resources\views/component/PaymentMethodList.blade.php ENDPATH**/ ?>